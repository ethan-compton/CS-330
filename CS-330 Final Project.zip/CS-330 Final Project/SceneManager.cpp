﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::DefineObjectMaterials() // called once from PrepareScene()
{
	// ALUMINUM (phone body)
	OBJECT_MATERIAL aluminum;
	aluminum.ambientColor = glm::vec3(0.22f, 0.22f, 0.24f);   // cool gray base tone
	aluminum.ambientStrength = 0.22f;                          // medium ambient
	aluminum.diffuseColor = glm::vec3(0.55f, 0.56f, 0.58f);   // light gray diffuse
	aluminum.specularColor = glm::vec3(0.35f, 0.35f, 0.36f);    // reduced shine
	aluminum.shininess = 32.0f;                          // less reflection
	aluminum.tag = "aluminum";
	m_objectMaterials.push_back(aluminum);

	// RUSTIC WOOD (table)
	OBJECT_MATERIAL rusticwood;
	rusticwood.ambientColor = glm::vec3(0.22f, 0.17f, 0.10f);  // warm brown base
	rusticwood.ambientStrength = 0.26f;
	rusticwood.diffuseColor = glm::vec3(0.45f, 0.30f, 0.18f);
	rusticwood.specularColor = glm::vec3(0.06f, 0.05f, 0.04f);
	rusticwood.shininess = 6.0f;                          // soft finish
	rusticwood.tag = "rusticwood";
	m_objectMaterials.push_back(rusticwood);

	// GRAY (speaker slot + camera)
	OBJECT_MATERIAL gray;
	gray.ambientColor = glm::vec3(0.22f, 0.22f, 0.22f);
	gray.ambientStrength = 0.22f;
	gray.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	gray.specularColor = glm::vec3(0.30f, 0.30f, 0.30f);
	gray.shininess = 24.0f;  // mild shine for plastic/metal blend
	gray.tag = "gray";
	m_objectMaterials.push_back(gray);

	// STAINLESS (side buttons)
	OBJECT_MATERIAL stainless;
	stainless.ambientColor = glm::vec3(0.28f, 0.28f, 0.28f);
	stainless.ambientStrength = 0.26f;
	stainless.diffuseColor = glm::vec3(0.70f, 0.70f, 0.75f);
	stainless.specularColor = glm::vec3(0.70f, 0.70f, 0.72f);
	stainless.shininess = 96.0f;  // bright polished metal
	stainless.tag = "stainless";
	m_objectMaterials.push_back(stainless);

	// DRYWALL
	OBJECT_MATERIAL drywall;
	drywall.ambientColor = glm::vec3(0.72f, 0.72f, 0.72f);
	drywall.ambientStrength = 0.20f;
	drywall.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	drywall.specularColor = glm::vec3(0.04f, 0.04f, 0.04f); // less reflection
	drywall.shininess = 4.0f;  // very soft light
	drywall.tag = "drywall";
	m_objectMaterials.push_back(drywall);

	// CERAMIC (mug)
	OBJECT_MATERIAL ceramic;
	ceramic.ambientColor = glm::vec3(0.85f, 0.85f, 0.86f);
	ceramic.ambientStrength = 0.30f;
	ceramic.diffuseColor = glm::vec3(0.95f, 0.95f, 0.97f);
	ceramic.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramic.shininess = 128.0f;   // glossy
	ceramic.tag = "ceramic";
	m_objectMaterials.push_back(ceramic);

	// Notebook Paper
	OBJECT_MATERIAL wood;
	wood.ambientColor = glm::vec3(0.6f, 0.5f, 0.4f);
	wood.ambientStrength = 0.25f;
	wood.diffuseColor = glm::vec3(0.8f, 0.7f, 0.5f);
	wood.specularColor = glm::vec3(0.3f, 0.2f, 0.1f);
	wood.shininess = 8.0f;  // soft finish
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);

	// Black
	OBJECT_MATERIAL black;
	black.ambientColor = glm::vec3(0.02f, 0.02f, 0.02f);
	black.ambientStrength = 0.20f;
	black.diffuseColor = glm::vec3(0.05f, 0.05f, 0.05f);
	black.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	black.shininess = 4.0f;  // very soft light
	black.tag = "black";
	m_objectMaterials.push_back(black);
}

void SceneManager::SetupSceneLights()
{
	// POINT 0 – key (white), high/front-left, softer spec
	m_pShaderManager->setVec3Value("lightSources[0].position", 7.0f, 8.5f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.55f, 0.55f, 0.57f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.60f, 0.60f, 0.60f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.35f);

	// POINT 1 – fill, low/back-right, softer spec
	const glm::vec3 dir = glm::normalize(glm::vec3(-0.35f, -1.0f, -0.25));
	m_pShaderManager->setVec3Value("dirLight.direction", dir);
	// directional light values
	m_pShaderManager->setVec3Value("dirLight.ambientColor", 0.12f, 0.10f, 0.08f); // warm light
	m_pShaderManager->setVec3Value("dirLight.diffuseColor", 0.95f, 0.82f, 0.65f);
	m_pShaderManager->setVec3Value("dirLight.specularColor", 0.90f, 0.678f, 0.70f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	// 

	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadConeMesh();


	// load the textures to be used in the 3D scene
	CreateGLTexture(
		"../../Utilities/Textures/aluminum.jpg", "aluminum"); // phone body texture
	CreateGLTexture(
		"../../Utilities/Textures/rusticwood.jpg", "rusticwood"); // table texture
	CreateGLTexture(
		"../../Utilities/Textures/gray.jpg", "gray"); // speaker slot and camera texture
	CreateGLTexture(
		"../../Utilities/Textures/stainless_end.jpg", "stainless"); // button texture
	CreateGLTexture(
		"../../Utilities/Textures/drywall.jpg", "drywall"); // phone screen texture
	CreateGLTexture(
		"../../Utilities/Textures/wood.jpg", "wood"); // notebook paper
	CreateGLTexture(
		"../../Utilities/Textures/black.jpg", "black"); // screen texture

	BindGLTextures();
	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("rusticwood"); // wood texture for the table)
	SetShaderMaterial("rusticwood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// background plane //
	scaleXYZ = glm::vec3(60.0f, 1.0f, 30.0f);
	XrotationDegrees = -90.0f;   // stand it up
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 15.0f, -40.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	SetShaderColor(0.00, 0.00f, 0.00f, 1.0f); // black
	m_basicMeshes->DrawPlaneMesh();

	/*************** NOTEBOOK — BACKING ***************/
	scaleXYZ = glm::vec3(2.20f, 0.06f, 2.90f); // slightly larger than pages
	XrotationDegrees = 0.0f; // no tilt
	YrotationDegrees = 35.0f; // angled like reference photo
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-5.30f, 0.15f, 2.20f); // left side of frame, on table

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("gray"); // gray for backing
	SetShaderMaterial("gray");
	m_basicMeshes->DrawBoxMesh();

	/*************** NOTEBOOK — PAGES ***************/
	scaleXYZ = glm::vec3(2.05f, 0.02f, 2.70f); // slightly smaller than backing
	XrotationDegrees = 0.0f; // no tilt
	YrotationDegrees = 35.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-5.30f, 0.20f, 2.20f); // a hair above backing

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood");
	SetShaderMaterial("wood"); // paper material
	m_basicMeshes->DrawBoxMesh();

	/********************* LAPTOP — BASE *********************/
	scaleXYZ = glm::vec3(3.60f, 0.16f, 2.60f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 85.0f; // sharp right angle
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-8.50f, 0.15f, 6.00f); // on table

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("aluminum"); // aluminum body
	SetShaderMaterial("aluminum");
	m_basicMeshes->DrawBoxMesh();

	/********************* LAPTOP — KEYBOARD DECK *********************/
	scaleXYZ = glm::vec3(3.38f, 0.02f, 2.40f); // slightly smaller than base
	XrotationDegrees = 0.0f;
	YrotationDegrees = 85.0f; // same as base
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-8.50f, 0.23f, 6.00f); // slightly above base

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("gray"); // gray for keyboard deck
	SetShaderMaterial("gray");
	m_basicMeshes->DrawBoxMesh();

	/********************* LAPTOP — TRACKPAD *********************/
	scaleXYZ = glm::vec3(0.90f, 0.01f, 0.60f); // smaller than deck
	XrotationDegrees = 0.0f;
	YrotationDegrees = 85.0f; // same as base
	ZrotationDegrees = 00.0f;
	positionXYZ = glm::vec3(-7.70f, 0.24f, 6.15f); // centered on deck, slightly above

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("stainless"); // stainless trackpad
	SetShaderMaterial("stainless");
	m_basicMeshes->DrawBoxMesh();

	/********************* LAPTOP — LID / OUTER FRAME *********************/
	scaleXYZ = glm::vec3(3.45f, 0.10f, 2.20f);
	XrotationDegrees = -92.0f; // tilted back
	YrotationDegrees = 0.0f; // no yaw
	ZrotationDegrees = 85.0f; // match base angle
	positionXYZ = glm::vec3(-9.67f, 1.36f, 6.00f); // back of base, on table

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("aluminum"); // aluminum body
	SetShaderMaterial("aluminum");
	m_basicMeshes->DrawBoxMesh();

/********************* LAPTOP — INNER BEZEL *********************/
	scaleXYZ = glm::vec3(3.20f, 0.02f, 1.98f); // slightly smaller than frame
	XrotationDegrees = -92.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 85.0f;
	positionXYZ = glm::vec3(-9.67f, 1.38f, 6.00f); // slightly above frame

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("gray"); // gray for bezel
	SetShaderMaterial("gray");
	m_basicMeshes->DrawBoxMesh();

	/********************* LAPTOP — SCREEN PANEL *********************/
	scaleXYZ = glm::vec3(2.95f, 0.01f, 1.78f); // slightly smaller than bezel
	XrotationDegrees = -92.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 85.0f;
	positionXYZ = glm::vec3(-9.62f, 1.395f, 6.00f); // slightly above bezel

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("black"); // screen texture
	SetShaderMaterial("black");
	m_basicMeshes->DrawBoxMesh();

	/************************* PEN — BODY *************************/
	scaleXYZ = glm::vec3(0.035f, 1.40f, 0.035f); // long and thin
	XrotationDegrees = 90.0f; // stand it up
	YrotationDegrees = -22.0f; // slight yaw to match notebook angle
	ZrotationDegrees = 0.0f; // no roll
	positionXYZ = glm::vec3(-5.55f, 0.24f, 2.85f); // on notebook

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("aluminum");
	SetShaderMaterial("aluminum"); // aluminum body
	m_basicMeshes->DrawCylinderMesh();

	/************* PEN — TIP *************/
	scaleXYZ = glm::vec3(0.050f, 0.12f, 0.050f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = -22.0f; // match pen yaw
	ZrotationDegrees = 180.0f; // flip it around

	positionXYZ = glm::vec3(-5.55f, 0.243f, 2.85f); // near top of pen body

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("stainless");
	SetShaderMaterial("stainless"); // shiny metal tip
	m_basicMeshes->DrawConeMesh();

	/************************* PEN — CLIP *************************/
	scaleXYZ = glm::vec3(0.02f, 0.30f, 0.01f); // very thin
	XrotationDegrees = 90.0f;
	YrotationDegrees = -22.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-5.600f, 0.243f, 4.00f); // near bottom of pen body

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("stainless");
	SetShaderMaterial("stainless"); // shiny metal clip
	m_basicMeshes->DrawBoxMesh();

	/********************* MUG — BODY (Cylinder) *********************/
	scaleXYZ = glm::vec3(0.70f, 1.00f, 0.70f); // slightly larger
	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f; // slight yaw
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-8.40f, 0.10f, 2.20f); // left side of laptop

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("ceramic"); // white ceramic mug
	m_basicMeshes->DrawCylinderMesh();

	/********************* MUG — HANDLE (Torus) *********************/
	scaleXYZ = glm::vec3(0.32f, 0.32f, 0.32f); // small torus
	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f; // match mug yaw
	ZrotationDegrees = 90.0f; // rotate to stand up

	positionXYZ = glm::vec3(-9.30f, 0.50f, 2.32f); // left side of mug body

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("ceramic"); // white ceramic mug handle
	m_basicMeshes->DrawTorusMesh();

	/********************* PHONE — BODY *********************/
	scaleXYZ = glm::vec3(1.32f, 0.16f, 2.58f); // slightly larger than screen
	XrotationDegrees = 0.0f;
	YrotationDegrees = -100.0f; // slight yaw
	ZrotationDegrees = 0.0f; 

	positionXYZ = glm::vec3(-4.50f, 0.15f, 5.40f); // on table in front of laptop

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("aluminum"); // phone body texture
	SetShaderMaterial("aluminum");
	m_basicMeshes->DrawBoxMesh();

	/*************** PHONE SCREEN ***************/
	scaleXYZ = glm::vec3(1.23f, 0.02, 2.46f); // slightly smaller than body
	XrotationDegrees = 0.0f;
	YrotationDegrees = -100.0f; // slight yaw
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-4.50f, 0.28, 5.40f); // aligned with body, raised slightly

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("black"); // screen texture
	SetShaderMaterial("black");
	m_basicMeshes->DrawBoxMesh();

	/********************* PHONE — SPEAKER SLOT *********************/
	scaleXYZ = glm::vec3(0.48f, 1.00f, 0.06f); // thin, flat slot
	XrotationDegrees = 0.0f;
	YrotationDegrees = -100.0f; // match phone tilt
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-5.55f, 0.30f, 5.20f); // top edge of phone, centered

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("gray"); // dark speaker slot
	SetShaderMaterial("gray");
	m_basicMeshes->DrawPlaneMesh();

	/********************* FRONT CAMERA *********************/
	scaleXYZ = glm::vec3(0.096f, 0.04f, 0.096f); // small cylinder   
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f; // match phone tilt
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-5.25f, 0.30f, 5.36f); // underneath speaker slot

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("gray"); // gray/black lens
	SetShaderMaterial("gray");
	m_basicMeshes->DrawCylinderMesh();

	/********************* PHONE — VOLUME BUTTON *********************/
	scaleXYZ = glm::vec3(0.036f, 0.10f, 0.384f); // longer bar
	XrotationDegrees = 0.0f;
	YrotationDegrees = -100.0f; // match phone tilt
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-4.246f, 0.22f, 6.10f); // left edge of phone, a bit lower

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("stainless"); // metallic button texture
	SetShaderMaterial("stainless");
	m_basicMeshes->DrawBoxMesh();

	/********************* PHONE — POWER BUTTON *********************/
	scaleXYZ = glm::vec3(0.036f, 0.10f, 0.216f); // shorter bar
	XrotationDegrees = 0.0f; // no tilt
	YrotationDegrees = -100.0f; // match phone tilt
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-5.246f, 0.24f, 6.00f); // left edge of phone, above volume button

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("stainless"); // metallic button texture
	SetShaderMaterial("stainless");
	m_basicMeshes->DrawBoxMesh();

}